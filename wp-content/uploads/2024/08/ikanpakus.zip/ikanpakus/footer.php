		<footer id="ikp-footer">
			<div class="ikp-footer__buttom-content">
				<p>Copyright &copy; <?= date("Y") ?></p>
			</div>
		</footer>
	</div>

	<?php wp_footer(); ?>

	</body>
</html>
<? get_header(); ?>

<div id="ikp-main-content">
    <?php the_content(); ?>
</div>

<? get_footer(); ?>